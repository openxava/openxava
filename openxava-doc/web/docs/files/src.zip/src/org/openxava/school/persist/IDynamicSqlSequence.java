package org.openxava.school.persist;

/**
 * Classes which need a SQL-based sequence number with a non-static query (e.g. the sequence depends on a parent key value) 
 * must implement this interface, and use the following field annotations on the field being generated:
 * 
 * <p><code>  @GenericGenerator(name="sql_seq_gen",strategy="org.openxava.school.persist.SqlSequenceGenerator")
 *  @GeneratedValue(generator="sql_seq_gen")</code></p>
 *  
 *  <p>The nextKeyQuery() method should return a query similar to this: 
 *  <code>select max(LEVEL2_ID) + 1 from LEVEL2 where LEVEL1_ID = 4</code>
 *  where the values for the parent keys are taken from the current object.</p>
 *
 * <p>Entity classes which can use a static query should specify the query in the <code>id_query</code> parameter
 * (see example below) and do <b>not</b> need to implement this interface.</p>
 * 
 * <p><code>  @GenericGenerator(name="sql_seq_gen",
 *    strategy="org.openxava.school.persist.SqlSequenceGenerator",
 *    parameters={
 *        @Parameter(name="id_query",value="select max(LEVEL1_ID) + 1 from LEVEL1")
 *    })
 *  @GeneratedValue(generator="sql_seq_gen")</code></p>
 * 
 * @author Roy Hellinga
 */
public interface IDynamicSqlSequence {

  /**
   * This method will be called to get the SQL query to be used to calculate the next available ID.
   * @return the SQL query to be used to generate the next available ID
   */
  String nextKeyQuery();

}