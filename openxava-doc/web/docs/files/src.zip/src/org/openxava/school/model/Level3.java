package org.openxava.school.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;
import org.openxava.annotations.*;
import org.openxava.school.persist.IDynamicSqlSequence;

@Tab(properties="level3Parent.level2Parent.level1Name,level3Parent.level2Name,level3Name") //also seems to work

@Entity
@IdClass(Level3Id.class)
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"LEVEL1_ID","LEVEL2_ID","LEVEL3_NAME"}))
public class Level3 implements IDynamicSqlSequence {
  
  // Annotations for this field are duplicated in the ID class due to a Hibernate bug -- please keep in sync!!!
  @Id
  @ManyToOne(fetch=FetchType.EAGER)
  @JoinColumns({
    @JoinColumn(name="LEVEL2_ID",referencedColumnName="LEVEL2_ID",nullable=false,unique=false,insertable=false,updatable=false),
    @JoinColumn(name="LEVEL1_ID",referencedColumnName="LEVEL1_ID",nullable=false,unique=false,insertable=false,updatable=false)
  })
  @DescriptionsList(descriptionProperties="level2Parent.level1Name,level2Name")
  private Level2 level3Parent;
  
  // Annotations for this field are duplicated in the ID class due to a Hibernate bug -- please keep in sync!!!
  @Id @Hidden
  @GenericGenerator(name="sql_seq_gen",strategy="org.openxava.school.persist.SqlSequenceGenerator")
  @GeneratedValue(generator="sql_seq_gen")
  @Column(length=5,name="LEVEL3_ID")
  private int level3Id;
  
  @Column(length=20,name="LEVEL3_NAME",nullable=false)
  @Required
  private String level3Name;

  public String getLevel3Name() {
    return level3Name;
  }

  public void setLevel3Name(String level3Name) {
    this.level3Name = level3Name;
  }

  public Level2 getLevel3Parent() {
    return level3Parent;
  }

  public void setLevel3Parent(Level2 parent) {
    this.level3Parent = parent;
  }

  public int getLevel3Id() {
    return level3Id;
  }

  public void setLevel3Id(int id) {
    this.level3Id = id;
  }

  @Override
  public String nextKeyQuery() {
    String myResult = String.format("select max(LEVEL3_ID) + 1 from LEVEL3 where LEVEL1_ID = %1$s and LEVEL2_ID = %2$s",
        level3Parent.getLevel2Parent().getLevel1Id(),
        level3Parent.getLevel2Id());
    return myResult;
  }

}
