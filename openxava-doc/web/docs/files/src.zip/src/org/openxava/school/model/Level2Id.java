package org.openxava.school.model;

import java.io.*;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;
import org.openxava.annotations.DescriptionsList;
import org.openxava.school.persist.IDynamicSqlSequence;


public class Level2Id implements Serializable, IDynamicSqlSequence {
  private static final long serialVersionUID = 1L;

  // These field annotations are duplicated from the entity class due to a Hibernate bug. Please keep in sync!!!
  // If the Hibernate bug gets fixed, these should all be removed.
  @Id
  @ManyToOne(fetch=FetchType.EAGER)
  @JoinColumn(name="LEVEL1_ID",referencedColumnName="LEVEL1_ID",nullable=false,unique=false,insertable=true,updatable=true)
  @DescriptionsList(descriptionProperties="level1Name")
  private Level1 level2Parent;

  // These field annotations are duplicated from the entity class due to a Hibernate bug. Please keep in sync!!!
  // If the Hibernate bug gets fixed, these should all be removed.
  @Id 
  @GenericGenerator(name="sql_seq_gen",strategy="org.openxava.school.persist.SqlSequenceGenerator")
  @GeneratedValue(generator="sql_seq_gen")
  @Column(length=5,name="LEVEL2_ID")
  private int level2Id;

  public Level1 getLevel2Parent() {
    return level2Parent;
  }

  public void setLevel2Parent(Level1 parent) {
    this.level2Parent = parent;
  }

  public int getLevel2Id() {
    return level2Id;
  }

  public void setLevel2Id(int id) {
    this.level2Id = id;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + level2Id;
    result = prime * result + ((level2Parent == null) ? 0 : level2Parent.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Level2Id other = (Level2Id) obj;
    if (level2Id != other.level2Id)
      return false;
    if (level2Parent == null) {
      if (other.level2Parent != null)
        return false;
    } else if (!level2Parent.equals(other.level2Parent))
      return false;
    return true;
  }

  @Override
  public String nextKeyQuery() {
    String myResult = new String("select max(LEVEL2_ID) + 1 from LEVEL2 where LEVEL1_ID = ");
    myResult += level2Parent.getLevel1Id();
    return myResult;
  }
}
