package org.openxava.school.persist;

import java.io.*;
import java.sql.*;
import java.util.*;

import org.apache.commons.logging.*;
import org.hibernate.*;
import org.hibernate.dialect.*;
import org.hibernate.engine.spi.*;
import org.hibernate.id.*;
import org.hibernate.type.*;

/**
 * Custom class to generate the next available sequence number appropriate for the context using SQL.
 * 
 * Classes which use this generator must implement IDynamicSqlSequence interface which requires the following method(s);  
 * a method which returns an SQL query to calculate the next sequence.
 * 
 * @author Roy Hellinga
 *
 */
public class SqlSequenceGenerator implements IdentifierGenerator, Configurable {
  public static final String PROPERTY_KEY_QUERY = "id_query";
  private static Log log = LogFactory.getLog(SqlSequenceGenerator.class);
  private Properties props = null;

  /* (non-Javadoc)
   * @see org.hibernate.id.IdentifierGenerator#generate(org.hibernate.engine.spi.SessionImplementor, java.lang.Object)
   */
  @Override
  public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
    Integer nextValue = new Integer(1);
    IDynamicSqlSequence myClass = null;
    ResultSet rs = null;
    
    String qs = null;
    if(props.containsKey(PROPERTY_KEY_QUERY)) {
      qs = props.getProperty(PROPERTY_KEY_QUERY);
      log.info("RH:Property-based query for next key=" + qs);
    }
    else
    {
      try {
        myClass = (IDynamicSqlSequence)object;
      }
      catch(Exception e) {
        log.error("Problem casting the Entity to the interface. Ensure interface IDynamicSqlSequence is implemented.",e);
        throw new HibernateException("Problem casting the Entity to the required interface",e);
      }
      qs = myClass.nextKeyQuery();
      if(qs == null) {
        log.error("RH:nextKeyQuery() returned null.");
        throw new HibernateException("nextKeyQuery() callback returned null");
      }
      else {
        log.info("RH:Callback query for next key=" + qs);
      }
    }
    
    try{
      rs = session.connection().createStatement().executeQuery(qs);
      if(rs.next()){
        int newId = rs.getInt(1);
        log.info("RH:Generated next key="+newId);
        nextValue = new Integer(newId);
      }
    }
    catch (SQLException e){
      log.error("Unexpected SQL Exception while calculating key value", e);
      throw new HibernateException(e);
    }
    finally {
      if (rs != null) {
        try {
          rs.close();
        }
        catch (Throwable t) {
          log.error("Unexpected exception closing result set", t);
          throw new HibernateException(t);
        }
      }
    }
    if(nextValue.intValue() < 1) {
      log.warn("RH:This must be the first row in this table -- setting initial value to 1");
      nextValue = new Integer(1);
    }
    return nextValue;

  }

  @Override
  public void configure(Type arg0, Properties arg1, Dialect arg2) throws MappingException {
    props = arg1;
  }

}
