package org.openxava.school.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.openxava.annotations.Hidden;
import org.openxava.annotations.Required;

@Entity
public class Level1 {
  
  // Annotations for this field are duplicated in the ID class due to a Hibernate bug -- please keep in sync!!!
  @Id @Hidden
  @Column(length=5,name="LEVEL1_ID")  
  @GenericGenerator(name="my_seq_gen",
    strategy="org.openxava.school.persist.SqlSequenceGenerator",
    parameters={
        @Parameter(name="id_query",value="select max(LEVEL1_ID) + 1 from LEVEL1")
    })
  @GeneratedValue(generator="my_seq_gen")
  private int level1Id;
  
  @Column(length=20,name="LEVEL1_NAME",unique=true,nullable=false)
  @Required
  private String level1Name;
  
  //Collections
  @OneToMany(mappedBy="level2Parent")
  private Collection<Level2> level1Children;
  
  public int getLevel1Id() {
    return level1Id;
  }
  public void setLevel1Id(int id) {
    this.level1Id = id;
  }
  public String getLevel1Name() {
    return level1Name;
  }
  public void setLevel1Name(String level1Name) {
    this.level1Name = level1Name;
  }
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + level1Id;
    return result;
  }
  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Level1 other = (Level1) obj;
    if (level1Id != other.level1Id)
      return false;
    return true;
  }
  public Collection<Level2> getLevel1Children() {
    return level1Children;
  }
  public void setLevel1Children(Collection<Level2> level1Children) {
    this.level1Children = level1Children;
  }

}
