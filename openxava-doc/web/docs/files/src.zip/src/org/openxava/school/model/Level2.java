package org.openxava.school.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;
import org.openxava.annotations.DescriptionsList;
import org.openxava.annotations.Hidden;
import org.openxava.annotations.Required;
import org.openxava.annotations.Tab;
import org.openxava.school.persist.IDynamicSqlSequence;

@Tab(properties="level2Parent.level1Name,level2Name",
    defaultOrder="${level2Parent.level1Name},${level2Name}")

@Entity
@IdClass(Level2Id.class)
@Table(uniqueConstraints=@UniqueConstraint(columnNames={"LEVEL1_ID","LEVEL2_NAME"}))
public class Level2 implements IDynamicSqlSequence {

  // Annotations for this field are duplicated in the ID class due to a Hibernate bug -- please keep in sync!!!
  @Id
  @ManyToOne(fetch=FetchType.EAGER)
  @JoinColumn(name="LEVEL1_ID",referencedColumnName="LEVEL1_ID",nullable=false,unique=false,insertable=true,updatable=true)
  @DescriptionsList(descriptionProperties="level1Name")
  private Level1 level2Parent;

  // Annotations for this field are duplicated in the ID class due to a Hibernate bug -- please keep in sync!!!
  @Id @Hidden
  @GenericGenerator(name="sql_seq_gen",strategy="org.openxava.school.persist.SqlSequenceGenerator")
  @GeneratedValue(generator="sql_seq_gen")
  @Column(length=5,name="LEVEL2_ID")
  private int level2Id;
  
  @Column(length=20,name="LEVEL2_NAME",nullable=false)
  @Required
  private String level2Name;

  @OneToMany(mappedBy="level3Parent")
  private Collection<Level3> level2Children;

  public String getLevel2Name() {
    return level2Name;
  }

  public void setLevel2Name(String level2Name) {
    this.level2Name = level2Name;
  }

  public Level1 getLevel2Parent() {
    return level2Parent;
  }

  public void setLevel2Parent(Level1 parent) {
    this.level2Parent = parent;
  }

  public int getLevel2Id() {
    return level2Id;
  }

  public void setLevel2Id(int id) {
    this.level2Id = id;
  }

  @Override
  public String nextKeyQuery() {
    String myResult = new String("select max(LEVEL2_ID) + 1 from LEVEL2 where LEVEL1_ID = ");
    myResult += level2Parent.getLevel1Id();
    return myResult;
  }

  public Collection<Level3> getLevel2Children() {
    return level2Children;
  }

  public void setLevel2Children(Collection<Level3> level2Children) {
    this.level2Children = level2Children;
  }

}
