package org.openxava.school.model;

import java.io.*;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;
import org.openxava.annotations.DescriptionsList;
import org.openxava.annotations.Hidden;
import org.openxava.school.persist.IDynamicSqlSequence;

public class Level3Id implements Serializable,IDynamicSqlSequence {
  private static final long serialVersionUID = 4L;

  // These field annotations are duplicated from the entity class due to a Hibernate bug. Please keep in sync!!!
  // If the Hibernate bug gets fixed, these should all be removed.
  @Id
  @ManyToOne(fetch=FetchType.EAGER)
  @JoinColumns({
    @JoinColumn(name="LEVEL2_ID",referencedColumnName="LEVEL2_ID",nullable=false,unique=false,insertable=false,updatable=false),
    @JoinColumn(name="LEVEL1_ID",referencedColumnName="LEVEL1_ID",nullable=false,unique=false,insertable=false,updatable=false)
  })
  @DescriptionsList(descriptionProperties="level2Parent.level1Name,level2Name")
  private Level2 level3Parent;

  // These field annotations are duplicated from the entity class due to a Hibernate bug. Please keep in sync!!!
  // If the Hibernate bug gets fixed, these should all be removed.
  @Id @Hidden
  @GenericGenerator(name="sql_seq_gen",strategy="org.openxava.school.persist.SqlSequenceGenerator")
  @GeneratedValue(generator="sql_seq_gen")
  @Column(length=5,name="LEVEL3_ID")
  private int level3Id;

  public Level2 getLevel3Parent() {
    return level3Parent;
  }

  public void setLevel3Parent(Level2 parent) {
    this.level3Parent = parent;
  }

  public int getLevel3Id() {
    return level3Id;
  }

  public void setLevel3Id(int id) {
    this.level3Id = id;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + level3Id;
    result = prime * result + ((level3Parent == null) ? 0 : level3Parent.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Level3Id other = (Level3Id) obj;
    if (level3Id != other.level3Id)
      return false;
    if (level3Parent == null) {
      if (other.level3Parent != null)
        return false;
    } else if (!level3Parent.equals(other.level3Parent))
      return false;
    return true;
  }

  @Override
  public String nextKeyQuery() {
    String myResult = String.format("select max(LEVEL3_ID) + 1 from LEVEL3 where LEVEL1_ID = %1$s and LEVEL2_ID = %2$s",
        level3Parent.getLevel2Parent().getLevel1Id(),
        level3Parent.getLevel2Id());
    return myResult;
  }

}
